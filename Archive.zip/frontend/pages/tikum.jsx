
import React from 'react'
import CardTimeline from '../components/CardTimeline'

function Tikum(){
  return(
    <>
      <div class="hero min-h-screen ">
  <div class="hero-content text-center">
    <div class="max-w-md">
      <h1 class="text-5xl font-bold ">Hello there</h1>
      <p class="py-6">Maaf guys fitur tikum hanya tersedia pada aplikasi mobile kami, silahkan download pada link dibawah.</p>
      <button class="btn btn-outline">Download</button>
    </div>
  </div>
</div>
    </>
  )
}
export default Tikum;