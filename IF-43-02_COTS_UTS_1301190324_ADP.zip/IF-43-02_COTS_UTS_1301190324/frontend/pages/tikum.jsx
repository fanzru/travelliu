
import React from 'react'
import CardTimeline from '../components/CardTimeline'

function Tikum(){
  return(
    <>
      <div className="hero min-h-screen ">
  <div className="hero-content text-center">
    <div className="max-w-md">
      <h1 className="text-5xl font-bold ">Hello there</h1>
      <p className="py-6">Maaf guys fitur tikum hanya tersedia pada aplikasi mobile kami, silahkan download pada link dibawah.</p>
      <button className="btn btn-outline">Download</button>
    </div>
  </div>
</div>
    </>
  )
}
export default Tikum;